# Dragon Slayer Academy

A browser-based, touch-first game built from the Sir Yes Sir PRD.

## What is included

- `index.html` - application shell and overlays
- `styles.css` - iPad-first landscape UI, large touch targets, portrait rotation prompt
- `game.js` - canvas game engine, math challenges, waves, boss fight, gestures, local save data, and WebAudio effects
- `manifest.webmanifest` - fullscreen landscape PWA metadata
- `service-worker.js` - offline cache when served over HTTP/HTTPS

## How to run

Open `index.html` directly in a browser, or serve the folder locally:

```bash
python3 -m http.server 8000
```

Then open the local server in Safari or Chrome. On iPad, use landscape orientation.

## Gameplay implemented from the PRD

- Sir Yes Sir as the playable knight
- Sword, Arrows, and Fireball weapons
- Math challenges to unlock or power up weapons
- First-try rewards: trophy star, stronger weapon, fanfare
- Fire, Ice, Armoured, and Shadow Dragons
- Hidden Shadow Dragon weakness discovery
- Touch gestures: sideways swipe to roll, upward swipe to jump, hold to shield
- Infinite lives: hits cause a stumble and encouraging recovery
- Wave trophies and saved score/star progress
- Boss Dragon that starts big, becomes massive, then fills the screen while Sir Yes Sir fights inside its shadow
- Boss requires all three weapons to finish
- 25-minute nudge and 30-minute session completion timer
- LocalStorage save data for best score, stars, first-try math accuracy, sessions, and boss wins

## Notes

This is a complete playable static MVP with no external libraries and no network assets. The waves are completion-based so the game can be play-tested quickly, while the real 25-minute and 30-minute session timers are implemented in code.
