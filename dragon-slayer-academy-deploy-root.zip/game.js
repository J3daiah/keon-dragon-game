(function () {
  'use strict';

  var CONFIG = {
    sessionLengthMs: 30 * 60 * 1000,
    nudgeMs: 25 * 60 * 1000,
    maxNormalWaves: 5,
    bossWaveLabel: 'BOSS',
    storageKey: 'dragonSlayerAcademySirYesSirV2'
  };

  var WEAPONS = {
    sword: {
      label: 'Sword',
      icon: '\u2694\ufe0f',
      cooldown: 520,
      baseDamage: 18,
      message: 'Close-range power strike!'
    },
    arrows: {
      label: 'Arrows',
      icon: '\ud83c\udff9',
      cooldown: 340,
      baseDamage: 12,
      message: 'Fast arrow shot!'
    },
    fireball: {
      label: 'Fireball',
      icon: '\u2728',
      cooldown: 760,
      baseDamage: 15,
      message: 'Magic splash attack!'
    }
  };

  var DRAGONS = {
    fire: {
      label: 'Fire Dragon',
      color: '#ff4e35',
      accent: '#ffd15f',
      weakTo: 'arrows',
      health: 32,
      speed: 42
    },
    ice: {
      label: 'Ice Dragon',
      color: '#55c7ff',
      accent: '#e9fbff',
      weakTo: 'fireball',
      health: 34,
      speed: 44
    },
    armoured: {
      label: 'Armoured Dragon',
      color: '#666d7f',
      accent: '#d8dced',
      weakTo: 'sword',
      health: 42,
      speed: 36
    },
    shadow: {
      label: 'Shadow Dragon',
      color: '#34204f',
      accent: '#c565ff',
      weakTo: 'fireball',
      health: 46,
      speed: 54,
      hiddenWeakness: true
    }
  };

  var encouragements = [
    'Almost, Sir Yes Sir! Try a different weapon!',
    'The dragon was fast this time -- you have got this, brave knight!',
    'Wrong weapon -- can you figure out its weakness?',
    'Sir Yes Sir gets back up and keeps going!'
  ];

  var canvas = document.getElementById('gameCanvas');
  var ctx = canvas.getContext('2d');
  var ui = {
    titleScreen: document.getElementById('titleScreen'),
    titleStats: document.getElementById('titleStats'),
    startButton: document.getElementById('startButton'),
    howButton: document.getElementById('howButton'),
    resetButton: document.getElementById('resetButton'),
    howPanel: document.getElementById('howPanel'),
    closeHowButton: document.getElementById('closeHowButton'),
    mathPanel: document.getElementById('mathPanel'),
    mathRibbon: document.getElementById('mathRibbon'),
    mathTitle: document.getElementById('mathTitle'),
    mathQuestion: document.getElementById('mathQuestion'),
    answerDisplay: document.getElementById('answerDisplay'),
    mathHint: document.getElementById('mathHint'),
    keypad: document.getElementById('keypad'),
    messagePanel: document.getElementById('messagePanel'),
    messageIcon: document.getElementById('messageIcon'),
    messageTitle: document.getElementById('messageTitle'),
    messageBody: document.getElementById('messageBody'),
    messageStats: document.getElementById('messageStats'),
    messageButton: document.getElementById('messageButton'),
    waveStat: document.getElementById('waveStat'),
    scoreStat: document.getElementById('scoreStat'),
    starStat: document.getElementById('starStat'),
    timeStat: document.getElementById('timeStat'),
    weaponButtons: Array.prototype.slice.call(document.querySelectorAll('.weaponButton')),
    attackButton: document.getElementById('attackButton'),
    soundToggle: document.getElementById('soundToggle'),
    toast: document.getElementById('toast')
  };

  var width = 0;
  var height = 0;
  var dpr = 1;
  var groundY = 0;
  var messageAction = null;
  var pointer = null;
  var holdTimer = null;
  var toastTimer = null;
  var idCounter = 1;

  var game = {
    mode: 'title',
    wave: 1,
    score: 0,
    stars: 0,
    sessionStart: 0,
    elapsedMs: 0,
    sessionQuestions: 0,
    sessionFirstTry: 0,
    currentWeapon: 'sword',
    empoweredWeapon: null,
    unlocked: {
      sword: false,
      arrows: false,
      fireball: false
    },
    knight: {
      x: 150,
      y: 0,
      action: 'ready',
      actionStart: 0,
      actionDuration: 1,
      rollDir: 1,
      shieldUntil: 0,
      invincibleUntil: 0,
      attackReadyAt: 0,
      lastHitAt: 0
    },
    dragons: [],
    projectiles: [],
    hazards: [],
    effects: [],
    boss: null,
    currentPlan: null,
    challenge: null,
    nudgeShown: false,
    finalShown: false,
    soundOn: true,
    audioCtx: null,
    save: loadSave(),
    lastFrame: 0
  };

  function loadSave() {
    var fallback = {
      sessions: 0,
      bestScore: 0,
      lastStars: 0,
      totalQuestions: 0,
      totalFirstTry: 0,
      bossesDefeated: 0
    };

    try {
      var raw = window.localStorage.getItem(CONFIG.storageKey);
      if (!raw) {
        return fallback;
      }
      var parsed = JSON.parse(raw);
      return Object.assign(fallback, parsed);
    } catch (error) {
      return fallback;
    }
  }

  function saveProgress() {
    game.save.bestScore = Math.max(game.save.bestScore || 0, game.score || 0);
    game.save.lastStars = game.stars || 0;
    try {
      window.localStorage.setItem(CONFIG.storageKey, JSON.stringify(game.save));
    } catch (error) {
      // localStorage can fail in private mode. The game still runs.
    }
    renderTitleStats();
  }

  function resetProgress() {
    game.save = {
      sessions: 0,
      bestScore: 0,
      lastStars: 0,
      totalQuestions: 0,
      totalFirstTry: 0,
      bossesDefeated: 0
    };
    try {
      window.localStorage.removeItem(CONFIG.storageKey);
    } catch (error) {
      // Ignore storage failures.
    }
    renderTitleStats();
    showToast('Progress reset. A fresh academy quest is ready!');
  }

  function renderTitleStats() {
    var accuracy = game.save.totalQuestions > 0
      ? Math.round((game.save.totalFirstTry / game.save.totalQuestions) * 100)
      : 0;
    ui.titleStats.innerHTML = '';
    ui.titleStats.appendChild(makeBadge('Best score: ' + game.save.bestScore));
    ui.titleStats.appendChild(makeBadge('Last trophy: ' + game.save.lastStars + ' stars'));
    ui.titleStats.appendChild(makeBadge('First-try math: ' + accuracy + '%'));
    ui.titleStats.appendChild(makeBadge('Boss wins: ' + game.save.bossesDefeated));
  }

  function makeBadge(text) {
    var badge = document.createElement('span');
    badge.className = 'badge';
    badge.textContent = text;
    return badge;
  }

  function resizeCanvas() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    width = Math.max(1, window.innerWidth);
    height = Math.max(1, window.innerHeight);
    canvas.width = Math.round(width * dpr);
    canvas.height = Math.round(height * dpr);
    canvas.style.width = width + 'px';
    canvas.style.height = height + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    groundY = height - Math.max(92, height * 0.16);
    game.knight.y = groundY;
  }

  function initKeypad() {
    var keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'Clear', '0', 'OK'];
    ui.keypad.innerHTML = '';
    keys.forEach(function (key) {
      var button = document.createElement('button');
      button.type = 'button';
      button.textContent = key;
      if (key === 'OK') {
        button.className = 'enterKey';
      } else if (key === 'Clear') {
        button.className = 'clearKey';
      }
      button.addEventListener('click', function () {
        handleKeypad(key);
      });
      ui.keypad.appendChild(button);
    });
  }

  function handleKeypad(key) {
    ensureAudio();
    if (!game.challenge) {
      return;
    }
    if (key === 'Clear') {
      game.challenge.answerText = '';
      ui.answerDisplay.textContent = '?';
      playSound('tap');
      return;
    }
    if (key === 'OK') {
      submitAnswer();
      return;
    }
    if (game.challenge.answerText.length < 4) {
      game.challenge.answerText += key;
      ui.answerDisplay.textContent = game.challenge.answerText;
      playSound('tap');
    }
  }

  function startQuest() {
    ensureAudio();
    game.mode = 'challenge';
    game.wave = 1;
    game.score = 0;
    game.stars = 0;
    game.sessionQuestions = 0;
    game.sessionFirstTry = 0;
    game.elapsedMs = 0;
    game.sessionStart = performance.now();
    game.currentWeapon = 'sword';
    game.empoweredWeapon = null;
    game.unlocked = { sword: false, arrows: false, fireball: false };
    game.dragons = [];
    game.projectiles = [];
    game.hazards = [];
    game.effects = [];
    game.boss = null;
    game.nudgeShown = false;
    game.finalShown = false;
    game.save.sessions += 1;
    saveProgress();
    hideAllPanels();
    prepareChallenge(getWavePlan(game.wave));
    updateUi();
  }

  function getWavePlan(wave) {
    if (wave > CONFIG.maxNormalWaves) {
      return {
        boss: true,
        wave: CONFIG.bossWaveLabel,
        weapon: 'all',
        title: 'Boss Dragon Challenge',
        ribbon: 'Unlock Every Weapon',
        types: [],
        count: 1
      };
    }

    var plans = [
      {
        wave: 1,
        title: 'Tutorial Battle',
        ribbon: 'Unlock Sword',
        weapon: 'sword',
        types: ['armoured'],
        count: 2,
        message: 'Armoured dragons are close. Try the sword.'
      },
      {
        wave: 2,
        title: 'Fire Dragon Battle',
        ribbon: 'Unlock Arrows',
        weapon: 'arrows',
        types: ['fire'],
        count: 3,
        message: 'Fire dragons rush fast. A sharp eye helps.'
      },
      {
        wave: 3,
        title: 'Ice Dragon Battle',
        ribbon: 'Unlock Fireball',
        weapon: 'fireball',
        types: ['ice'],
        count: 3,
        message: 'Ice dragons sparkle, but magic can melt them.'
      },
      {
        wave: 4,
        title: 'Mixed Dragon Battle',
        ribbon: 'Power Up Arrows',
        weapon: 'arrows',
        types: ['fire', 'armoured', 'ice'],
        count: 5,
        message: 'Now the academy tests pattern finding.'
      },
      {
        wave: 5,
        title: 'Shadow Dragon Battle',
        ribbon: 'Power Up Sword',
        weapon: 'sword',
        types: ['shadow', 'fire', 'armoured', 'ice'],
        count: 6,
        message: 'The shadow dragon hides its weakness. Try, notice, and adapt.'
      }
    ];

    return plans[wave - 1];
  }

  function prepareChallenge(plan) {
    game.mode = 'challenge';
    game.currentPlan = plan;
    game.challenge = makeQuestion(plan);
    ui.mathRibbon.textContent = plan.ribbon;
    ui.mathTitle.textContent = plan.boss ? 'The boss dragon is awakening!' : plan.title;
    ui.mathQuestion.textContent = game.challenge.text;
    ui.answerDisplay.textContent = '?';
    ui.mathHint.textContent = '';
    showOnlyPanel(ui.mathPanel);
    updateUi();
  }

  function makeQuestion(plan) {
    var wave = plan.boss ? 6 : plan.wave;
    var question;

    if (plan.boss) {
      var bossQuestions = [
        {
          text: 'The boss dragon has 144 shadow scales. Sir Yes Sir breaks 12 each combo. How many combos are needed?',
          answer: 12,
          hint: 'Think: 12 x ? = 144.'
        },
        {
          text: 'Three weapons each strike 9 times. How many total strikes hit the boss?',
          answer: 27,
          hint: 'Three groups of 9.'
        },
        {
          text: 'The giant dragon has 96 shields. Fireballs break 8 at a time. How many fireballs break them all?',
          answer: 12,
          hint: 'Think: 96 divided by 8.'
        }
      ];
      question = bossQuestions[Math.floor(Math.random() * bossQuestions.length)];
      return Object.assign({ answerText: '', attempts: 0 }, question);
    }

    var weaponLabel = WEAPONS[plan.weapon].label;
    var type = wave % 3;
    if (wave === 1) {
      question = {
        text: '4 x 3 = ? Solve it to unlock your ' + weaponLabel + '!',
        answer: 12,
        hint: 'Count four groups of three.'
      };
    } else if (type === 2) {
      var a = 5 + wave;
      var b = 3 + Math.floor(Math.random() * 6);
      question = {
        text: a + ' x ' + b + ' = ? Unlock your ' + weaponLabel + '!',
        answer: a * b,
        hint: 'Break it apart: ' + a + ' x ' + b + ' means ' + b + ' groups of ' + a + '.'
      };
    } else if (type === 0) {
      var divisor = 4 + Math.floor(Math.random() * 6);
      var quotient = 4 + wave;
      var dividend = divisor * quotient;
      question = {
        text: dividend + ' / ' + divisor + ' = ? Unlock your ' + weaponLabel + '!',
        answer: quotient,
        hint: 'Ask: ' + divisor + ' x ? = ' + dividend + '.'
      };
    } else {
      var shields = (6 + wave) * 6;
      question = {
        text: 'The dragon has ' + shields + ' shields. You break 6 per strike. How many strikes do you need?',
        answer: shields / 6,
        hint: 'Divide the shields into groups of 6.'
      };
    }

    return Object.assign({ answerText: '', attempts: 0 }, question);
  }

  function submitAnswer() {
    if (!game.challenge) {
      return;
    }
    var value = parseInt(game.challenge.answerText, 10);
    if (Number.isNaN(value)) {
      ui.mathHint.textContent = 'Type your answer first, brave knight.';
      playSound('wrong');
      return;
    }

    if (value === game.challenge.answer) {
      var firstTry = game.challenge.attempts === 0;
      var plan = game.currentPlan;
      game.sessionQuestions += 1;
      game.save.totalQuestions += 1;

      if (firstTry) {
        game.sessionFirstTry += 1;
        game.save.totalFirstTry += 1;
        game.stars += 1;
        game.score += plan.boss ? 250 : 80;
        game.empoweredWeapon = plan.boss ? 'all' : plan.weapon;
        playFanfare();
        showToast('First try! Bonus star, extra power, and fanfare!');
      } else {
        game.empoweredWeapon = null;
        playSound('correct');
        showToast('Correct! Weapon unlocked. Sir Yes Sir is ready!');
      }

      if (plan.boss) {
        game.unlocked.sword = true;
        game.unlocked.arrows = true;
        game.unlocked.fireball = true;
        game.currentWeapon = 'sword';
      } else {
        game.unlocked[plan.weapon] = true;
        game.currentWeapon = plan.weapon;
      }

      saveProgress();
      hideAllPanels();
      beginBattle(plan);
      return;
    }

    game.challenge.attempts += 1;
    game.challenge.answerText = '';
    ui.answerDisplay.textContent = '?';
    ui.mathHint.textContent = 'Almost, Sir Yes Sir! ' + game.challenge.hint;
    playSound('wrong');
  }

  function beginBattle(plan) {
    game.mode = 'playing';
    game.dragons = [];
    game.projectiles = [];
    game.hazards = [];
    game.effects = [];
    game.boss = null;
    game.knight.action = 'ready';
    game.knight.shieldUntil = 0;
    game.knight.invincibleUntil = performance.now() + 900;

    if (plan.boss) {
      startBoss();
      showToast('The boss dragon starts big... and keeps growing!');
      playSound('boss');
    } else {
      spawnWave(plan);
      showToast(plan.message || 'Battle begins!');
      playSound('start');
    }
    updateUi();
  }

  function spawnWave(plan) {
    var lanes = [groundY - 70, groundY - 140, groundY - 215];
    for (var i = 0; i < plan.count; i += 1) {
      var type = plan.types[i % plan.types.length];
      var base = DRAGONS[type];
      game.dragons.push({
        id: nextId(),
        type: type,
        label: base.label,
        color: base.color,
        accent: base.accent,
        weakTo: base.weakTo,
        hiddenWeakness: !!base.hiddenWeakness,
        discovered: !base.hiddenWeakness,
        x: width + 110 + i * 145 + Math.random() * 80,
        y: lanes[i % lanes.length] - Math.random() * 30,
        baseY: lanes[i % lanes.length],
        radius: type === 'armoured' ? 44 : 39,
        health: base.health + game.wave * 4,
        maxHealth: base.health + game.wave * 4,
        speed: base.speed + game.wave * 5 + Math.random() * 8,
        wobble: Math.random() * 10,
        attackReadyAt: 0,
        hitFlash: 0,
        alive: true
      });
    }
  }

  function nextId() {
    idCounter += 1;
    return idCounter;
  }

  function startBoss() {
    game.boss = {
      id: nextId(),
      health: 430,
      maxHealth: 430,
      x: width - 260,
      y: Math.max(190, height * 0.42),
      phase: 1,
      lastPhase: 1,
      attackTimer: 1.4,
      hitWeapons: {
        sword: false,
        arrows: false,
        fireball: false
      },
      defeated: false,
      hitFlash: 0,
      growPulse: 0
    };
  }

  function loop(now) {
    var dt = Math.min(0.04, Math.max(0, (now - game.lastFrame) / 1000 || 0));
    game.lastFrame = now;
    update(dt, now);
    draw(now);
    window.requestAnimationFrame(loop);
  }

  function update(dt, now) {
    if (game.sessionStart > 0 && game.mode !== 'title') {
      game.elapsedMs = now - game.sessionStart;
    }

    updateEffects(dt);

    if (game.mode === 'playing') {
      updateKnight(now);
      updateProjectiles(dt, now);
      updateHazards(dt, now);

      if (game.boss) {
        updateBoss(dt, now);
      } else {
        updateDragons(dt, now);
        if (game.dragons.length > 0 && game.dragons.every(function (dragon) { return !dragon.alive; })) {
          completeWave();
        }
      }

      if (!game.nudgeShown && game.elapsedMs >= CONFIG.nudgeMs) {
        game.nudgeShown = true;
        showToast('One final battle, Sir Yes Sir!');
      }

      if (!game.finalShown && game.elapsedMs >= CONFIG.sessionLengthMs && !game.boss) {
        game.finalShown = true;
        finishSession('Academy Complete!', 'Thirty heroic minutes are complete. Sir Yes Sir trained focus, courage, and math power today.');
      }
    }

    updateUi();
  }

  function updateKnight(now) {
    if (game.knight.action !== 'ready' && now > game.knight.actionStart + game.knight.actionDuration) {
      game.knight.action = 'ready';
    }
  }

  function updateDragons(dt, now) {
    game.dragons.forEach(function (dragon) {
      if (!dragon.alive) {
        return;
      }
      dragon.wobble += dt * 4;
      dragon.x -= dragon.speed * dt;
      dragon.y = dragon.baseY + Math.sin(dragon.wobble) * 16;
      dragon.hitFlash = Math.max(0, dragon.hitFlash - dt * 5);

      if (dragon.x < -80) {
        dragon.x = width + 120 + Math.random() * 180;
        dragon.baseY = groundY - 70 - Math.floor(Math.random() * 3) * 70;
      }

      if (dragon.x < game.knight.x + 78 && dragon.x > game.knight.x - 36 && now > dragon.attackReadyAt) {
        dragon.attackReadyAt = now + 1600;
        dragon.x += 120;
        knightHit(now, dragon.label + ' bumped Sir Yes Sir!');
      }
    });
  }

  function updateProjectiles(dt, now) {
    var alive = [];
    game.projectiles.forEach(function (projectile) {
      if (projectile.done) {
        return;
      }
      var target = findTargetById(projectile.targetId) || findNearestTarget();
      if (!target) {
        projectile.x += projectile.vx * dt;
        projectile.y += projectile.vy * dt;
      } else {
        var tx = target.x;
        var ty = target.y;
        if (target.isBoss && target.phase === 3) {
          tx = width * 0.62;
          ty = height * 0.45;
        }
        var dx = tx - projectile.x;
        var dy = ty - projectile.y;
        var dist = Math.max(1, Math.hypot(dx, dy));
        projectile.x += (dx / dist) * projectile.speed * dt;
        projectile.y += (dy / dist) * projectile.speed * dt;
        if (dist < projectile.hitRadius + (target.radius || 80)) {
          projectile.done = true;
          if (target.isBoss) {
            damageBoss(projectile.weapon, projectile.damage, now);
          } else {
            damageDragon(target, projectile.weapon, projectile.damage, now);
          }
          if (projectile.weapon === 'fireball') {
            splashFireball(projectile.x, projectile.y, projectile.damage, target, now);
          }
          addBurst(projectile.x, projectile.y, projectile.weapon);
        }
      }

      if (projectile.x > width + 160 || projectile.y < -100 || projectile.y > height + 100) {
        projectile.done = true;
      }

      if (!projectile.done) {
        alive.push(projectile);
      }
    });
    game.projectiles = alive;
  }

  function updateHazards(dt, now) {
    var active = [];
    game.hazards.forEach(function (hazard) {
      hazard.y += hazard.speed * dt;
      hazard.spin += dt * 5;
      if (!hazard.hit && hazard.y > groundY - 28) {
        hazard.hit = true;
        addBurst(hazard.x, groundY - 18, 'fireball');
        if (Math.abs(hazard.x - currentKnightX(now)) < hazard.radius + 42) {
          knightHit(now, 'The dragon was fast this time -- shield or dodge!');
        }
      }
      if (hazard.y < height + 120) {
        active.push(hazard);
      }
    });
    game.hazards = active;
  }

  function updateBoss(dt, now) {
    var boss = game.boss;
    if (!boss || boss.defeated) {
      return;
    }

    var ratio = boss.health / boss.maxHealth;
    boss.phase = ratio > 0.66 ? 1 : ratio > 0.33 ? 2 : 3;
    boss.hitFlash = Math.max(0, boss.hitFlash - dt * 5);
    boss.growPulse += dt;

    if (boss.phase !== boss.lastPhase) {
      boss.lastPhase = boss.phase;
      if (boss.phase === 2) {
        showToast('The boss dragon is MASSIVE -- it fills half the screen!');
        playSound('boss');
      } else if (boss.phase === 3) {
        showToast('The boss dragon takes over the screen! Fight inside its shadow!');
        playSound('boss');
      }
    }

    boss.attackTimer -= dt;
    if (boss.attackTimer <= 0) {
      spawnBossHazard(boss.phase);
      boss.attackTimer = boss.phase === 1 ? 1.7 : boss.phase === 2 ? 1.25 : 0.9;
    }
  }

  function spawnBossHazard(phase) {
    var count = phase === 1 ? 1 : phase === 2 ? 2 : 3;
    for (var i = 0; i < count; i += 1) {
      var targetX = game.knight.x + (Math.random() * 180 - 90) + i * 35;
      game.hazards.push({
        id: nextId(),
        x: clamp(targetX, 80, width - 80),
        y: -60 - i * 70,
        speed: 240 + phase * 60 + Math.random() * 40,
        radius: 30 + phase * 3,
        spin: Math.random() * 6,
        hit: false
      });
    }
  }

  function updateEffects(dt) {
    var kept = [];
    game.effects.forEach(function (effect) {
      effect.life -= dt;
      effect.age += dt;
      effect.y += effect.vy * dt;
      effect.x += effect.vx * dt;
      if (effect.life > 0) {
        kept.push(effect);
      }
    });
    game.effects = kept;
  }

  function attack(now) {
    if (game.mode !== 'playing') {
      return;
    }
    ensureAudio();
    var weapon = game.currentWeapon;
    if (!game.unlocked[weapon]) {
      showToast('Solve a weapon challenge to unlock ' + WEAPONS[weapon].label + '.');
      playSound('wrong');
      return;
    }
    if (now < game.knight.attackReadyAt) {
      return;
    }
    game.knight.attackReadyAt = now + WEAPONS[weapon].cooldown;
    game.knight.action = 'attack';
    game.knight.actionStart = now;
    game.knight.actionDuration = 230;

    if (weapon === 'sword') {
      swordAttack(now);
    } else {
      projectileAttack(weapon, now);
    }
    playSound(weapon);
  }

  function swordAttack(now) {
    var target = null;
    if (game.boss) {
      target = bossTarget();
    } else {
      target = game.dragons
        .filter(function (dragon) {
          return dragon.alive && dragon.x > game.knight.x - 20 && dragon.x < game.knight.x + 190;
        })
        .sort(function (a, b) { return a.x - b.x; })[0];
    }

    var slashX = game.knight.x + 88;
    var slashY = currentKnightY(now) - 78;
    game.effects.push({
      type: 'slash',
      x: slashX,
      y: slashY,
      vx: 0,
      vy: 0,
      life: 0.22,
      age: 0,
      weapon: 'sword'
    });

    if (target) {
      if (target.isBoss) {
        damageBoss('sword', WEAPONS.sword.baseDamage, now);
      } else {
        damageDragon(target, 'sword', WEAPONS.sword.baseDamage, now);
      }
    } else {
      showToast('Sword needs close range. Roll near a dragon or switch weapons!');
    }
  }

  function projectileAttack(weapon, now) {
    var target = findNearestTarget();
    if (!target) {
      showToast('No dragon target yet. Stay ready!');
      return;
    }
    var startX = game.knight.x + 64;
    var startY = currentKnightY(now) - 86;
    game.projectiles.push({
      id: nextId(),
      weapon: weapon,
      x: startX,
      y: startY,
      vx: weapon === 'arrows' ? 760 : 520,
      vy: 0,
      speed: weapon === 'arrows' ? 720 : 500,
      targetId: target.id,
      damage: WEAPONS[weapon].baseDamage,
      hitRadius: weapon === 'fireball' ? 34 : 18,
      done: false,
      age: 0
    });
  }

  function splashFireball(x, y, damage, primaryTarget, now) {
    if (game.boss) {
      return;
    }
    game.dragons.forEach(function (dragon) {
      if (!dragon.alive || dragon.id === primaryTarget.id) {
        return;
      }
      var dist = Math.hypot(dragon.x - x, dragon.y - y);
      if (dist < 112) {
        damageDragon(dragon, 'fireball', damage * 0.65, now);
      }
    });
  }

  function findNearestTarget() {
    if (game.boss && !game.boss.defeated) {
      return bossTarget();
    }
    var alive = game.dragons.filter(function (dragon) { return dragon.alive; });
    if (alive.length === 0) {
      return null;
    }
    alive.sort(function (a, b) {
      return Math.abs(a.x - game.knight.x) - Math.abs(b.x - game.knight.x);
    });
    return alive[0];
  }

  function findTargetById(id) {
    if (game.boss && game.boss.id === id && !game.boss.defeated) {
      return bossTarget();
    }
    for (var i = 0; i < game.dragons.length; i += 1) {
      if (game.dragons[i].id === id && game.dragons[i].alive) {
        return game.dragons[i];
      }
    }
    return null;
  }

  function bossTarget() {
    var boss = game.boss;
    var phase = boss ? boss.phase : 1;
    return {
      id: boss.id,
      isBoss: true,
      phase: phase,
      x: phase === 1 ? width - 260 : phase === 2 ? width - 180 : width * 0.62,
      y: phase === 1 ? height * 0.42 : phase === 2 ? height * 0.45 : height * 0.42,
      radius: phase === 1 ? 140 : phase === 2 ? 235 : 360
    };
  }

  function damageDragon(dragon, weapon, amount, now) {
    if (!dragon || !dragon.alive) {
      return;
    }
    var isWeak = dragon.weakTo === weapon;
    var damage = isWeak ? amount * 1.55 : Math.max(3, amount * 0.28);
    if (game.empoweredWeapon === weapon || game.empoweredWeapon === 'all') {
      damage *= 1.45;
    }
    dragon.health -= damage;
    dragon.hitFlash = 1;

    if (isWeak) {
      if (dragon.hiddenWeakness && !dragon.discovered) {
        dragon.discovered = true;
        showToast('Discovery! Shadow Dragon is weak to ' + WEAPONS[weapon].label + '!');
      } else {
        showToast('Great choice! ' + dragon.label + ' is weak to ' + WEAPONS[weapon].label + '.');
      }
      game.score += Math.round(6 + damage);
      playSound('hit');
    } else {
      showToast(encouragements[Math.floor(Math.random() * encouragements.length)]);
      playSound('wrongWeapon');
    }

    game.effects.push({
      type: 'text',
      x: dragon.x,
      y: dragon.y - 55,
      vx: 0,
      vy: -42,
      life: 0.8,
      age: 0,
      text: '-' + Math.round(damage)
    });

    if (dragon.health <= 0) {
      dragon.alive = false;
      game.score += 110 + game.wave * 10;
      addBurst(dragon.x, dragon.y, weapon);
      showToast(dragon.label + ' defeated! Trophy power grows!');
      playSound('defeat');
    }
  }

  function damageBoss(weapon, amount, now) {
    var boss = game.boss;
    if (!boss || boss.defeated) {
      return;
    }
    boss.hitWeapons[weapon] = true;
    var damage = amount * (boss.phase === 3 ? 1.25 : 1);
    if (game.empoweredWeapon === weapon || game.empoweredWeapon === 'all') {
      damage *= 1.45;
    }
    boss.health -= damage;
    boss.hitFlash = 1;
    game.score += Math.round(12 + damage);
    game.effects.push({
      type: 'text',
      x: boss.phase === 3 ? width * 0.62 : bossTarget().x,
      y: boss.phase === 3 ? height * 0.23 : bossTarget().y - 120,
      vx: 0,
      vy: -45,
      life: 0.8,
      age: 0,
      text: WEAPONS[weapon].label + ' hit!'
    });

    if (allBossWeaponsUsed()) {
      showToast('All three weapons are shining together!');
    } else {
      showToast('Use every weapon to weaken the boss dragon!');
    }

    playSound('hit');

    if (boss.health <= 0) {
      if (!allBossWeaponsUsed()) {
        boss.health = 1;
        showToast('The boss hangs on! Sword, Arrows, and Fireball must all strike!');
      } else {
        boss.defeated = true;
        game.score += 1000 + game.stars * 80;
        addBurst(width * 0.62, height * 0.35, 'fireball');
        completeBoss();
      }
    }
  }

  function allBossWeaponsUsed() {
    var hit = game.boss && game.boss.hitWeapons;
    return !!(hit && hit.sword && hit.arrows && hit.fireball);
  }

  function knightHit(now, message) {
    if (now < game.knight.invincibleUntil) {
      return;
    }
    if (now < game.knight.shieldUntil) {
      showToast('Shield block! Sir Yes Sir stands strong!');
      addBurst(game.knight.x + 34, currentKnightY(now) - 70, 'sword');
      playSound('shield');
      game.score += 20;
      game.knight.invincibleUntil = now + 650;
      return;
    }
    if (game.knight.action === 'roll' || game.knight.action === 'jump') {
      showToast('Nice dodge! The dragon missed!');
      playSound('dodge');
      game.score += 25;
      game.knight.invincibleUntil = now + 450;
      return;
    }

    game.knight.action = 'stumble';
    game.knight.actionStart = now;
    game.knight.actionDuration = 600;
    game.knight.invincibleUntil = now + 1200;
    game.knight.lastHitAt = now;
    showToast(message || 'Sir Yes Sir stumbles, gets back up, and keeps fighting!');
    playSound('stumble');
  }

  function dodgeRoll(direction, now) {
    if (game.mode !== 'playing') {
      return;
    }
    game.knight.action = 'roll';
    game.knight.rollDir = direction || 1;
    game.knight.actionStart = now || performance.now();
    game.knight.actionDuration = 480;
    game.knight.invincibleUntil = game.knight.actionStart + 470;
    playSound('dodge');
    showToast(direction > 0 ? 'Roll right!' : 'Roll left!');
  }

  function jump(now) {
    if (game.mode !== 'playing') {
      return;
    }
    game.knight.action = 'jump';
    game.knight.actionStart = now || performance.now();
    game.knight.actionDuration = 650;
    game.knight.invincibleUntil = game.knight.actionStart + 620;
    playSound('dodge');
    showToast('Jump!');
  }

  function shield(now) {
    if (game.mode !== 'playing') {
      return;
    }
    var t = now || performance.now();
    game.knight.action = 'shield';
    game.knight.actionStart = t;
    game.knight.actionDuration = 760;
    game.knight.shieldUntil = t + 760;
    playSound('shield');
    showToast('Shield block!');
  }

  function completeWave() {
    if (game.mode !== 'playing') {
      return;
    }
    game.mode = 'waveComplete';
    game.score += 160 + game.wave * 35;
    saveProgress();
    playFanfare();
    showMessage({
      icon: '\ud83c\udfc6',
      title: 'Wave Cleared!',
      body: 'A big shiny trophy appears. Sir Yes Sir earned more dragon-slayer courage!',
      stats: [
        'Stars: ' + game.stars,
        'Score: ' + game.score,
        'Math first try: ' + game.sessionFirstTry + '/' + game.sessionQuestions
      ],
      button: game.wave >= CONFIG.maxNormalWaves ? 'Face the Boss Dragon' : 'Next Battle',
      action: function () {
        hideAllPanels();
        game.wave += 1;
        prepareChallenge(getWavePlan(game.wave));
      }
    });
  }

  function completeBoss() {
    if (game.mode === 'bossComplete') {
      return;
    }
    game.mode = 'bossComplete';
    game.save.bossesDefeated += 1;
    saveProgress();
    playFanfare();
    showMessage({
      icon: '\ud83c\udfc6',
      title: 'Sir Yes Sir wins!',
      body: 'Sir Yes Sir -- the bravest knight in all the land! The boss dragon filled the screen, but courage, math, and every weapon won the day.',
      stats: [
        'Final score: ' + game.score,
        'Trophy stars: ' + game.stars,
        'Best score: ' + game.save.bestScore
      ],
      button: 'Play Again Tomorrow',
      action: function () {
        hideAllPanels();
        game.mode = 'title';
        showOnlyPanel(ui.titleScreen);
      }
    });
  }

  function finishSession(title, body) {
    if (game.mode !== 'playing') {
      return;
    }
    game.mode = 'sessionComplete';
    saveProgress();
    playFanfare();
    showMessage({
      icon: '\ud83c\udfc6',
      title: title,
      body: body,
      stats: [
        'Score: ' + game.score,
        'Stars: ' + game.stars,
        'Math first try: ' + game.sessionFirstTry + '/' + game.sessionQuestions
      ],
      button: 'Return to Academy',
      action: function () {
        hideAllPanels();
        game.mode = 'title';
        showOnlyPanel(ui.titleScreen);
      }
    });
  }

  function showMessage(options) {
    ui.messageIcon.textContent = options.icon || '\ud83c\udfc6';
    ui.messageTitle.textContent = options.title;
    ui.messageBody.textContent = options.body;
    ui.messageStats.innerHTML = '';
    (options.stats || []).forEach(function (stat) {
      ui.messageStats.appendChild(makeBadge(stat));
    });
    ui.messageButton.textContent = options.button || 'Continue';
    messageAction = options.action || null;
    showOnlyPanel(ui.messagePanel);
  }

  function hideAllPanels() {
    [ui.titleScreen, ui.mathPanel, ui.messagePanel, ui.howPanel].forEach(function (panel) {
      panel.classList.add('hidden');
      panel.classList.remove('active');
    });
  }

  function showOnlyPanel(panel) {
    hideAllPanels();
    panel.classList.remove('hidden');
    panel.classList.add('active');
  }

  function updateUi() {
    ui.waveStat.textContent = game.boss ? 'BOSS' : game.mode === 'title' ? '-' : game.wave;
    ui.scoreStat.textContent = String(game.score);
    ui.starStat.textContent = String(game.stars);
    ui.timeStat.textContent = formatRemainingTime();

    ui.weaponButtons.forEach(function (button) {
      var weapon = button.getAttribute('data-weapon');
      button.classList.toggle('active', weapon === game.currentWeapon);
      button.classList.toggle('locked', !game.unlocked[weapon]);
      button.setAttribute('aria-pressed', weapon === game.currentWeapon ? 'true' : 'false');
      button.setAttribute('aria-disabled', game.unlocked[weapon] ? 'false' : 'true');
    });

    ui.soundToggle.textContent = game.soundOn ? 'Sound On' : 'Sound Off';
    ui.soundToggle.setAttribute('aria-pressed', game.soundOn ? 'true' : 'false');
  }

  function formatRemainingTime() {
    if (game.sessionStart <= 0 || game.mode === 'title') {
      return '30:00';
    }
    var remaining = Math.max(0, CONFIG.sessionLengthMs - game.elapsedMs);
    var totalSeconds = Math.ceil(remaining / 1000);
    var minutes = Math.floor(totalSeconds / 60);
    var seconds = totalSeconds % 60;
    return minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
  }

  function draw(now) {
    ctx.clearRect(0, 0, width, height);
    drawBackground(now);

    if (game.mode === 'title') {
      drawTitleDecor(now);
    }

    drawHazards(now);

    if (game.boss) {
      drawBoss(now);
    } else {
      game.dragons.forEach(function (dragon) {
        if (dragon.alive) {
          drawDragon(dragon, now);
        }
      });
    }

    drawProjectiles(now);
    drawKnight(now);
    drawEffects(now);
  }

  function drawBackground(now) {
    var sky = ctx.createLinearGradient(0, 0, 0, height);
    sky.addColorStop(0, '#93e4ff');
    sky.addColorStop(0.45, '#d8f7ff');
    sky.addColorStop(0.65, '#fce6a4');
    sky.addColorStop(1, '#7043a3');
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, width, height);

    drawSun(now);
    drawCloud(width * 0.14, height * 0.2, 1.1, now);
    drawCloud(width * 0.78, height * 0.16, 0.85, now + 1000);

    drawMountain(0, groundY - 10, width * 0.34, height * 0.34, '#7647a8', '#4f2f83');
    drawMountain(width * 0.16, groundY + 4, width * 0.48, height * 0.42, '#8d5ec0', '#5f3a96');
    drawMountain(width * 0.54, groundY, width * 0.38, height * 0.36, '#7445a9', '#553184');

    var ground = ctx.createLinearGradient(0, groundY - 16, 0, height);
    ground.addColorStop(0, '#72d56a');
    ground.addColorStop(1, '#27864d');
    ctx.fillStyle = ground;
    ctx.fillRect(0, groundY - 20, width, height - groundY + 20);

    ctx.fillStyle = 'rgba(255,255,255,0.25)';
    for (var i = 0; i < 12; i += 1) {
      var x = (i * 137 + (now * 0.012)) % (width + 80) - 40;
      ctx.beginPath();
      ctx.ellipse(x, groundY + 34 + (i % 3) * 18, 36, 7, 0, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  function drawSun(now) {
    var x = width * 0.88;
    var y = height * 0.2;
    var pulse = 1 + Math.sin(now / 900) * 0.04;
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(pulse, pulse);
    ctx.fillStyle = '#ffe879';
    ctx.beginPath();
    ctx.arc(0, 0, 42, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = 'rgba(255, 216, 64, 0.45)';
    ctx.lineWidth = 10;
    ctx.stroke();
    ctx.restore();
  }

  function drawCloud(x, y, scale, now) {
    var drift = Math.sin(now / 2500 + x) * 10;
    ctx.save();
    ctx.translate(x + drift, y);
    ctx.scale(scale, scale);
    ctx.fillStyle = 'rgba(255,255,255,0.74)';
    ctx.beginPath();
    ctx.ellipse(-38, 10, 42, 20, 0, 0, Math.PI * 2);
    ctx.ellipse(0, 0, 48, 28, 0, 0, Math.PI * 2);
    ctx.ellipse(44, 10, 42, 20, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  function drawMountain(x, baseY, mountainWidth, mountainHeight, colorA, colorB) {
    var gradient = ctx.createLinearGradient(x, baseY - mountainHeight, x, baseY);
    gradient.addColorStop(0, colorA);
    gradient.addColorStop(1, colorB);
    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.moveTo(x - 40, baseY);
    ctx.lineTo(x + mountainWidth * 0.45, baseY - mountainHeight);
    ctx.lineTo(x + mountainWidth + 40, baseY);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = 'rgba(255,255,255,0.65)';
    ctx.beginPath();
    ctx.moveTo(x + mountainWidth * 0.45, baseY - mountainHeight);
    ctx.lineTo(x + mountainWidth * 0.33, baseY - mountainHeight * 0.72);
    ctx.lineTo(x + mountainWidth * 0.55, baseY - mountainHeight * 0.75);
    ctx.closePath();
    ctx.fill();
  }

  function drawTitleDecor(now) {
    ctx.save();
    ctx.globalAlpha = 0.45;
    var fake = {
      type: 'fire',
      color: DRAGONS.fire.color,
      accent: DRAGONS.fire.accent,
      x: width * 0.78,
      y: height * 0.48 + Math.sin(now / 600) * 18,
      radius: 70,
      health: 1,
      maxHealth: 1,
      hitFlash: 0,
      discovered: true,
      label: 'Fire Dragon'
    };
    drawDragon(fake, now);
    ctx.restore();
  }

  function drawKnight(now) {
    var x = currentKnightX(now);
    var y = currentKnightY(now);
    var action = game.knight.action;
    var shieldActive = now < game.knight.shieldUntil || action === 'shield';
    var stumbled = action === 'stumble';

    ctx.save();
    ctx.translate(x, y);
    if (stumbled) {
      var p = actionProgress(now);
      ctx.rotate(Math.sin(p * Math.PI * 2) * 0.15);
    }
    if (action === 'roll') {
      ctx.scale(1.12, 0.74);
    }

    ctx.fillStyle = 'rgba(0,0,0,0.23)';
    ctx.beginPath();
    ctx.ellipse(0, 8, 55, 14, 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#cbd5e8';
    ctx.strokeStyle = '#5b6680';
    ctx.lineWidth = 4;
    roundRect(ctx, -28, -78, 56, 72, 18);
    ctx.fill();
    ctx.stroke();

    var armor = ctx.createLinearGradient(-32, -92, 34, -24);
    armor.addColorStop(0, '#ffffff');
    armor.addColorStop(0.5, '#cdd8ed');
    armor.addColorStop(1, '#7d8aa6');
    ctx.fillStyle = armor;
    roundRect(ctx, -24, -92, 48, 42, 16);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = '#f8d18f';
    ctx.beginPath();
    ctx.arc(0, -108, 24, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#dfe8f5';
    ctx.strokeStyle = '#58657a';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(-32, -112);
    ctx.quadraticCurveTo(0, -152, 34, -112);
    ctx.lineTo(25, -96);
    ctx.lineTo(-23, -96);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = '#4b2eb2';
    ctx.beginPath();
    ctx.moveTo(0, -148);
    ctx.quadraticCurveTo(22, -166, 44, -148);
    ctx.quadraticCurveTo(19, -140, 0, -148);
    ctx.fill();

    ctx.fillStyle = '#1d2140';
    ctx.fillRect(-16, -112, 32, 7);
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(-10, -111, 7, 4);
    ctx.fillRect(4, -111, 7, 4);

    ctx.strokeStyle = '#66728c';
    ctx.lineWidth = 8;
    ctx.beginPath();
    ctx.moveTo(-20, -46);
    ctx.lineTo(-36, -4);
    ctx.moveTo(20, -46);
    ctx.lineTo(36, -4);
    ctx.stroke();

    drawHeldWeapon(action);

    if (shieldActive) {
      var shieldGlow = ctx.createRadialGradient(50, -64, 8, 50, -64, 62);
      shieldGlow.addColorStop(0, 'rgba(255,255,255,0.95)');
      shieldGlow.addColorStop(1, 'rgba(95,198,255,0.1)');
      ctx.fillStyle = shieldGlow;
      ctx.beginPath();
      ctx.ellipse(54, -62, 42, 58, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#4fb9ff';
      ctx.lineWidth = 5;
      ctx.stroke();
    }

    ctx.restore();

    ctx.save();
    ctx.font = '900 18px Trebuchet MS, Arial';
    ctx.textAlign = 'center';
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = 'rgba(0,0,0,0.35)';
    ctx.lineWidth = 5;
    ctx.strokeText('Sir Yes Sir', x, y - 160);
    ctx.fillText('Sir Yes Sir', x, y - 160);
    ctx.restore();
  }

  function drawHeldWeapon(action) {
    var weapon = game.currentWeapon;
    ctx.save();
    if (weapon === 'sword') {
      ctx.translate(38, -72);
      ctx.rotate(action === 'attack' ? -0.9 : -0.45);
      ctx.fillStyle = '#f7fbff';
      ctx.strokeStyle = '#68748e';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(0, -62);
      ctx.lineTo(10, 0);
      ctx.lineTo(-10, 0);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = '#ffd45a';
      ctx.fillRect(-22, 0, 44, 9);
    } else if (weapon === 'arrows') {
      ctx.translate(38, -74);
      ctx.strokeStyle = '#7b4d24';
      ctx.lineWidth = 6;
      ctx.beginPath();
      ctx.arc(0, 0, 34, -1.2, 1.2);
      ctx.stroke();
      ctx.strokeStyle = '#f7fbff';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(-2, -34);
      ctx.lineTo(-2, 34);
      ctx.stroke();
    } else {
      ctx.translate(42, -84);
      var glow = ctx.createRadialGradient(0, 0, 2, 0, 0, 34);
      glow.addColorStop(0, '#fffef3');
      glow.addColorStop(0.45, '#ffd15f');
      glow.addColorStop(1, 'rgba(255,84,58,0.2)');
      ctx.fillStyle = glow;
      ctx.beginPath();
      ctx.arc(0, 0, 28, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  function currentKnightX(now) {
    var x = game.knight.x;
    if (game.knight.action === 'roll') {
      x += Math.sin(actionProgress(now) * Math.PI) * 72 * game.knight.rollDir;
    }
    return clamp(x, 82, width - 90);
  }

  function currentKnightY(now) {
    var y = groundY;
    if (game.knight.action === 'jump') {
      y -= Math.sin(actionProgress(now) * Math.PI) * 126;
    }
    if (game.knight.action === 'stumble') {
      y += Math.sin(actionProgress(now) * Math.PI) * 12;
    }
    return y;
  }

  function actionProgress(now) {
    var p = (now - game.knight.actionStart) / Math.max(1, game.knight.actionDuration);
    return clamp(p, 0, 1);
  }

  function drawDragon(dragon, now) {
    var x = dragon.x;
    var y = dragon.y;
    var scale = dragon.radius / 42;
    var flash = dragon.hitFlash || 0;
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(scale, scale);

    ctx.fillStyle = 'rgba(0,0,0,0.2)';
    ctx.beginPath();
    ctx.ellipse(0, 42, 58, 13, 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = flash > 0 ? '#ffffff' : dragon.color;
    ctx.strokeStyle = '#2e1d35';
    ctx.lineWidth = 4;

    ctx.beginPath();
    ctx.moveTo(-20, -10);
    ctx.lineTo(-80, -60);
    ctx.lineTo(-58, 4);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(6, -10);
    ctx.lineTo(76, -64);
    ctx.lineTo(56, 6);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    ctx.beginPath();
    ctx.ellipse(0, 0, 62, 38, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(-52, 6);
    ctx.quadraticCurveTo(-102, 10, -126, 48);
    ctx.strokeStyle = dragon.color;
    ctx.lineWidth = 18;
    ctx.stroke();

    ctx.fillStyle = flash > 0 ? '#ffffff' : dragon.accent;
    ctx.beginPath();
    ctx.ellipse(48, -10, 34, 27, 0.08, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#2e1d35';
    ctx.lineWidth = 4;
    ctx.stroke();

    ctx.fillStyle = '#151515';
    ctx.beginPath();
    ctx.arc(60, -16, 4, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#fff4db';
    ctx.beginPath();
    ctx.moveTo(74, -3);
    ctx.lineTo(86, 1);
    ctx.lineTo(75, 7);
    ctx.closePath();
    ctx.fill();

    if (dragon.type === 'armoured') {
      ctx.strokeStyle = '#eef2ff';
      ctx.lineWidth = 4;
      for (var i = -38; i <= 30; i += 18) {
        ctx.beginPath();
        ctx.moveTo(i, -34);
        ctx.lineTo(i + 14, 28);
        ctx.stroke();
      }
    }

    if (dragon.type === 'shadow' && !dragon.discovered) {
      ctx.fillStyle = 'rgba(255,255,255,0.92)';
      ctx.font = '900 28px Trebuchet MS, Arial';
      ctx.textAlign = 'center';
      ctx.fillText('?', 0, 10);
    }

    ctx.restore();

    drawHealthBar(x - 48, y - dragon.radius - 34, 96, 12, dragon.health / dragon.maxHealth);

    ctx.save();
    ctx.font = '900 15px Trebuchet MS, Arial';
    ctx.textAlign = 'center';
    ctx.fillStyle = '#ffffff';
    ctx.strokeStyle = 'rgba(0,0,0,0.4)';
    ctx.lineWidth = 4;
    var label = dragon.hiddenWeakness && !dragon.discovered ? 'Shadow Dragon: weakness ???' : dragon.label;
    ctx.strokeText(label, x, y - dragon.radius - 42);
    ctx.fillText(label, x, y - dragon.radius - 42);
    ctx.restore();
  }

  function drawBoss(now) {
    var boss = game.boss;
    if (!boss) {
      return;
    }
    var phase = boss.phase;

    if (phase === 3) {
      drawFullScreenBoss(boss, now);
      return;
    }

    var target = bossTarget();
    var scale = phase === 1 ? 2.2 : 3.35;
    var dragon = {
      type: 'boss',
      color: boss.hitFlash > 0 ? '#ffffff' : '#4b143d',
      accent: '#ff7b30',
      x: target.x,
      y: target.y + Math.sin(now / 420) * 8,
      radius: 58 * scale,
      health: boss.health,
      maxHealth: boss.maxHealth,
      hitFlash: boss.hitFlash,
      discovered: true,
      label: phase === 1 ? 'Boss Dragon: starts big' : 'Boss Dragon: MASSIVE'
    };

    ctx.save();
    ctx.translate(target.x, target.y);
    ctx.scale(scale, scale);
    ctx.fillStyle = 'rgba(0,0,0,0.28)';
    ctx.beginPath();
    ctx.ellipse(0, 90, 90, 22, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    drawDragon(dragon, now);
    drawBossHealthBar(boss);
    drawBossWeaponSeals(boss);
  }

  function drawFullScreenBoss(boss, now) {
    var pulse = 1 + Math.sin(now / 240) * 0.035;
    ctx.save();
    ctx.fillStyle = 'rgba(12, 4, 29, 0.74)';
    ctx.fillRect(0, 0, width, height);

    var aura = ctx.createRadialGradient(width * 0.5, height * 0.42, 20, width * 0.5, height * 0.42, Math.max(width, height) * 0.75);
    aura.addColorStop(0, 'rgba(255, 107, 46, 0.25)');
    aura.addColorStop(0.38, 'rgba(74, 20, 61, 0.72)');
    aura.addColorStop(1, 'rgba(0, 0, 0, 0.9)');
    ctx.fillStyle = aura;
    ctx.fillRect(0, 0, width, height);

    ctx.translate(width * 0.54, height * 0.4);
    ctx.scale(pulse, pulse);

    ctx.fillStyle = boss.hitFlash > 0 ? '#ffffff' : '#22081f';
    ctx.beginPath();
    ctx.ellipse(0, 40, width * 0.62, height * 0.55, 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = '#150316';
    ctx.beginPath();
    ctx.moveTo(-width * 0.25, -height * 0.16);
    ctx.lineTo(-width * 0.08, -height * 0.45);
    ctx.lineTo(width * 0.01, -height * 0.16);
    ctx.closePath();
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(width * 0.18, -height * 0.16);
    ctx.lineTo(width * 0.36, -height * 0.45);
    ctx.lineTo(width * 0.4, -height * 0.12);
    ctx.closePath();
    ctx.fill();

    drawGiantEye(-width * 0.16, -height * 0.04, now);
    drawGiantEye(width * 0.22, -height * 0.04, now + 500);

    ctx.fillStyle = '#050105';
    ctx.beginPath();
    ctx.ellipse(width * 0.03, height * 0.22, width * 0.18, height * 0.08, 0, 0, Math.PI);
    ctx.fill();

    ctx.fillStyle = '#fff4da';
    for (var i = -4; i <= 4; i += 1) {
      ctx.beginPath();
      ctx.moveTo(i * 30, height * 0.17);
      ctx.lineTo(i * 30 + 12, height * 0.25);
      ctx.lineTo(i * 30 - 12, height * 0.25);
      ctx.closePath();
      ctx.fill();
    }

    ctx.restore();

    ctx.save();
    ctx.font = '900 23px Trebuchet MS, Arial';
    ctx.textAlign = 'center';
    ctx.fillStyle = '#fff4ce';
    ctx.strokeStyle = 'rgba(0,0,0,0.5)';
    ctx.lineWidth = 6;
    ctx.strokeText('Sir Yes Sir is fighting from inside the boss shadow!', width * 0.5, height * 0.22);
    ctx.fillText('Sir Yes Sir is fighting from inside the boss shadow!', width * 0.5, height * 0.22);
    ctx.restore();

    drawBossHealthBar(boss);
    drawBossWeaponSeals(boss);
  }

  function drawGiantEye(x, y, now) {
    ctx.save();
    ctx.translate(x, y);
    ctx.fillStyle = '#ffdf57';
    ctx.beginPath();
    ctx.ellipse(0, 0, 80, 34, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#ff6b30';
    ctx.beginPath();
    ctx.arc(Math.sin(now / 500) * 8, 0, 21, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#160414';
    ctx.beginPath();
    ctx.arc(Math.sin(now / 500) * 8, 0, 10, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  function drawBossHealthBar(boss) {
    var barWidth = Math.min(520, width * 0.54);
    drawHealthBar(width * 0.5 - barWidth * 0.5, 72, barWidth, 18, boss.health / boss.maxHealth, '#ff6b30');
    ctx.save();
    ctx.font = '900 18px Trebuchet MS, Arial';
    ctx.textAlign = 'center';
    ctx.fillStyle = '#fff';
    ctx.strokeStyle = 'rgba(0,0,0,0.45)';
    ctx.lineWidth = 4;
    ctx.strokeText('Boss Dragon', width * 0.5, 62);
    ctx.fillText('Boss Dragon', width * 0.5, 62);
    ctx.restore();
  }

  function drawBossWeaponSeals(boss) {
    var weapons = ['sword', 'arrows', 'fireball'];
    var startX = width * 0.5 - 105;
    var y = 106;
    weapons.forEach(function (weapon, index) {
      var x = startX + index * 105;
      ctx.save();
      ctx.fillStyle = boss.hitWeapons[weapon] ? '#79f4a6' : 'rgba(255,255,255,0.8)';
      ctx.strokeStyle = '#40205f';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(x, y, 28, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.font = '900 22px Trebuchet MS, Arial';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = '#2a164b';
      ctx.fillText(WEAPONS[weapon].icon, x, y + 1);
      ctx.restore();
    });
  }

  function drawHealthBar(x, y, w, h, ratio, fillColor) {
    var safeRatio = clamp(ratio, 0, 1);
    ctx.save();
    ctx.fillStyle = 'rgba(0,0,0,0.28)';
    roundRect(ctx, x, y, w, h, h / 2);
    ctx.fill();
    ctx.fillStyle = fillColor || '#6df2ad';
    roundRect(ctx, x, y, w * safeRatio, h, h / 2);
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.75)';
    ctx.lineWidth = 2;
    roundRect(ctx, x, y, w, h, h / 2);
    ctx.stroke();
    ctx.restore();
  }

  function drawProjectiles(now) {
    game.projectiles.forEach(function (projectile) {
      ctx.save();
      ctx.translate(projectile.x, projectile.y);
      if (projectile.weapon === 'arrows') {
        ctx.strokeStyle = '#6e421e';
        ctx.lineWidth = 5;
        ctx.beginPath();
        ctx.moveTo(-30, 0);
        ctx.lineTo(25, 0);
        ctx.stroke();
        ctx.fillStyle = '#eef4ff';
        ctx.beginPath();
        ctx.moveTo(28, 0);
        ctx.lineTo(14, -9);
        ctx.lineTo(14, 9);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = '#7ad7ff';
        ctx.fillRect(-34, -9, 16, 7);
        ctx.fillRect(-34, 2, 16, 7);
      } else {
        var glow = ctx.createRadialGradient(0, 0, 3, 0, 0, 38);
        glow.addColorStop(0, '#fff8cf');
        glow.addColorStop(0.35, '#ffd15f');
        glow.addColorStop(0.72, '#ff553d');
        glow.addColorStop(1, 'rgba(255,85,61,0.05)');
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(0, 0, 38 + Math.sin(now / 70) * 4, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    });
  }

  function drawHazards(now) {
    game.hazards.forEach(function (hazard) {
      ctx.save();
      ctx.translate(hazard.x, hazard.y);
      ctx.rotate(hazard.spin);
      var glow = ctx.createRadialGradient(0, 0, 4, 0, 0, hazard.radius + 18);
      glow.addColorStop(0, '#fff5b8');
      glow.addColorStop(0.45, '#ff8330');
      glow.addColorStop(1, 'rgba(255,60,30,0.06)');
      ctx.fillStyle = glow;
      ctx.beginPath();
      ctx.arc(0, 0, hazard.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    });
  }

  function drawEffects(now) {
    game.effects.forEach(function (effect) {
      var alpha = clamp(effect.life / Math.max(0.01, effect.life + effect.age), 0, 1);
      ctx.save();
      ctx.globalAlpha = alpha;
      if (effect.type === 'text') {
        ctx.font = '900 23px Trebuchet MS, Arial';
        ctx.textAlign = 'center';
        ctx.fillStyle = '#ffffff';
        ctx.strokeStyle = 'rgba(0,0,0,0.5)';
        ctx.lineWidth = 5;
        ctx.strokeText(effect.text, effect.x, effect.y);
        ctx.fillText(effect.text, effect.x, effect.y);
      } else if (effect.type === 'slash') {
        ctx.translate(effect.x, effect.y);
        ctx.strokeStyle = '#fff8b4';
        ctx.lineWidth = 12;
        ctx.beginPath();
        ctx.arc(0, 0, 72, -0.8, 0.8);
        ctx.stroke();
      } else {
        ctx.fillStyle = effect.color || '#fff6a3';
        ctx.beginPath();
        ctx.arc(effect.x, effect.y, effect.size * alpha, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    });
  }

  function addBurst(x, y, weapon) {
    var color = weapon === 'fireball' ? '#ff8a32' : weapon === 'arrows' ? '#89d9ff' : '#fff4a4';
    for (var i = 0; i < 18; i += 1) {
      var angle = (Math.PI * 2 * i) / 18;
      var speed = 55 + Math.random() * 95;
      game.effects.push({
        type: 'particle',
        x: x,
        y: y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        life: 0.55 + Math.random() * 0.25,
        age: 0,
        size: 12 + Math.random() * 18,
        color: color
      });
    }
  }

  function roundRect(context, x, y, w, h, r) {
    var radius = Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2);
    context.beginPath();
    context.moveTo(x + radius, y);
    context.arcTo(x + w, y, x + w, y + h, radius);
    context.arcTo(x + w, y + h, x, y + h, radius);
    context.arcTo(x, y + h, x, y, radius);
    context.arcTo(x, y, x + w, y, radius);
    context.closePath();
  }

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function showToast(message) {
    ui.toast.textContent = message;
    ui.toast.classList.add('show');
    if (toastTimer) {
      window.clearTimeout(toastTimer);
    }
    toastTimer = window.setTimeout(function () {
      ui.toast.classList.remove('show');
    }, 1700);
  }

  function ensureAudio() {
    if (!game.soundOn) {
      return;
    }
    if (!window.AudioContext && !window.webkitAudioContext) {
      return;
    }
    if (!game.audioCtx) {
      var AudioContextCtor = window.AudioContext || window.webkitAudioContext;
      game.audioCtx = new AudioContextCtor();
    }
    if (game.audioCtx.state === 'suspended') {
      game.audioCtx.resume().catch(function () {});
    }
  }

  function playTone(frequency, duration, type, volume, delay) {
    if (!game.soundOn) {
      return;
    }
    ensureAudio();
    if (!game.audioCtx) {
      return;
    }
    var ctxAudio = game.audioCtx;
    var osc = ctxAudio.createOscillator();
    var gain = ctxAudio.createGain();
    var start = ctxAudio.currentTime + (delay || 0);
    osc.type = type || 'sine';
    osc.frequency.setValueAtTime(frequency, start);
    gain.gain.setValueAtTime(0.0001, start);
    gain.gain.exponentialRampToValueAtTime(volume || 0.06, start + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + duration);
    osc.connect(gain);
    gain.connect(ctxAudio.destination);
    osc.start(start);
    osc.stop(start + duration + 0.02);
  }

  function playSound(name) {
    if (name === 'tap') {
      playTone(520, 0.07, 'sine', 0.03);
    } else if (name === 'correct') {
      playTone(660, 0.12, 'triangle', 0.06);
      playTone(880, 0.12, 'triangle', 0.05, 0.08);
    } else if (name === 'wrong') {
      playTone(190, 0.18, 'sawtooth', 0.035);
    } else if (name === 'sword') {
      playTone(420, 0.08, 'square', 0.045);
      playTone(760, 0.06, 'triangle', 0.035, 0.04);
    } else if (name === 'arrows') {
      playTone(740, 0.05, 'triangle', 0.035);
    } else if (name === 'fireball') {
      playTone(180, 0.15, 'sawtooth', 0.045);
      playTone(520, 0.16, 'triangle', 0.035, 0.04);
    } else if (name === 'hit') {
      playTone(320, 0.08, 'square', 0.035);
    } else if (name === 'defeat') {
      playTone(520, 0.09, 'triangle', 0.05);
      playTone(720, 0.1, 'triangle', 0.05, 0.06);
      playTone(960, 0.12, 'triangle', 0.05, 0.12);
    } else if (name === 'dodge') {
      playTone(680, 0.08, 'sine', 0.04);
    } else if (name === 'shield') {
      playTone(260, 0.16, 'triangle', 0.05);
      playTone(520, 0.12, 'triangle', 0.04, 0.05);
    } else if (name === 'stumble') {
      playTone(150, 0.2, 'sawtooth', 0.035);
    } else if (name === 'boss') {
      playTone(90, 0.35, 'sawtooth', 0.055);
      playTone(130, 0.28, 'sawtooth', 0.04, 0.12);
    } else if (name === 'start') {
      playTone(392, 0.09, 'triangle', 0.04);
      playTone(523, 0.12, 'triangle', 0.04, 0.1);
    } else if (name === 'wrongWeapon') {
      playTone(240, 0.08, 'square', 0.03);
      playTone(190, 0.1, 'square', 0.025, 0.05);
    }
  }

  function playFanfare() {
    playTone(523, 0.14, 'triangle', 0.055, 0);
    playTone(659, 0.14, 'triangle', 0.055, 0.12);
    playTone(784, 0.18, 'triangle', 0.055, 0.24);
    playTone(1046, 0.28, 'triangle', 0.055, 0.38);
  }

  function bindEvents() {
    window.addEventListener('resize', resizeCanvas);
    window.addEventListener('orientationchange', function () {
      window.setTimeout(resizeCanvas, 250);
    });

    ui.startButton.addEventListener('click', startQuest);
    ui.howButton.addEventListener('click', function () {
      showOnlyPanel(ui.howPanel);
    });
    ui.closeHowButton.addEventListener('click', function () {
      showOnlyPanel(ui.titleScreen);
    });
    ui.resetButton.addEventListener('click', resetProgress);
    ui.messageButton.addEventListener('click', function () {
      if (messageAction) {
        messageAction();
      }
    });
    ui.soundToggle.addEventListener('click', function () {
      game.soundOn = !game.soundOn;
      if (game.soundOn) {
        ensureAudio();
        playSound('correct');
      }
      updateUi();
    });

    ui.weaponButtons.forEach(function (button) {
      button.addEventListener('click', function () {
        var weapon = button.getAttribute('data-weapon');
        ensureAudio();
        if (!game.unlocked[weapon]) {
          showToast(WEAPONS[weapon].label + ' is locked. Solve a math challenge to unlock it!');
          playSound('wrong');
          return;
        }
        game.currentWeapon = weapon;
        showToast(WEAPONS[weapon].icon + ' ' + WEAPONS[weapon].message);
        playSound('tap');
        updateUi();
      });
    });

    ui.attackButton.addEventListener('click', function () {
      attack(performance.now());
    });

    canvas.addEventListener('pointerdown', handlePointerDown, { passive: false });
    canvas.addEventListener('pointermove', handlePointerMove, { passive: false });
    canvas.addEventListener('pointerup', handlePointerUp, { passive: false });
    canvas.addEventListener('pointercancel', clearPointer, { passive: false });

    window.addEventListener('keydown', function (event) {
      if (game.mode === 'challenge' && game.challenge) {
        if (/^[0-9]$/.test(event.key)) {
          handleKeypad(event.key);
        } else if (event.key === 'Enter') {
          submitAnswer();
        } else if (event.key === 'Backspace') {
          game.challenge.answerText = game.challenge.answerText.slice(0, -1);
          ui.answerDisplay.textContent = game.challenge.answerText || '?';
        }
        return;
      }

      if (event.key === '1') {
        chooseWeapon('sword');
      } else if (event.key === '2') {
        chooseWeapon('arrows');
      } else if (event.key === '3') {
        chooseWeapon('fireball');
      } else if (event.key === ' ') {
        attack(performance.now());
      } else if (event.key === 'ArrowUp') {
        jump(performance.now());
      } else if (event.key === 'ArrowLeft') {
        dodgeRoll(-1, performance.now());
      } else if (event.key === 'ArrowRight') {
        dodgeRoll(1, performance.now());
      } else if (event.key.toLowerCase() === 's') {
        shield(performance.now());
      }
    });
  }

  function chooseWeapon(weapon) {
    if (!game.unlocked[weapon]) {
      showToast(WEAPONS[weapon].label + ' is locked.');
      return;
    }
    game.currentWeapon = weapon;
    updateUi();
  }

  function handlePointerDown(event) {
    if (game.mode !== 'playing') {
      return;
    }
    event.preventDefault();
    ensureAudio();
    pointer = {
      id: event.pointerId,
      x: event.clientX,
      y: event.clientY,
      time: performance.now(),
      swiped: false,
      held: false
    };
    try {
      canvas.setPointerCapture(event.pointerId);
    } catch (error) {
      // Some browsers do not need capture.
    }
    if (holdTimer) {
      window.clearTimeout(holdTimer);
    }
    holdTimer = window.setTimeout(function () {
      if (pointer && !pointer.swiped) {
        pointer.held = true;
        shield(performance.now());
      }
    }, 430);
  }

  function handlePointerMove(event) {
    if (!pointer || event.pointerId !== pointer.id || game.mode !== 'playing') {
      return;
    }
    event.preventDefault();
    var dx = event.clientX - pointer.x;
    var dy = event.clientY - pointer.y;
    var now = performance.now();
    if (!pointer.swiped && Math.abs(dx) > 68 && Math.abs(dx) > Math.abs(dy) * 1.25) {
      pointer.swiped = true;
      if (holdTimer) {
        window.clearTimeout(holdTimer);
      }
      dodgeRoll(dx > 0 ? 1 : -1, now);
    } else if (!pointer.swiped && dy < -66 && Math.abs(dy) > Math.abs(dx) * 1.1) {
      pointer.swiped = true;
      if (holdTimer) {
        window.clearTimeout(holdTimer);
      }
      jump(now);
    }
  }

  function handlePointerUp(event) {
    if (!pointer || event.pointerId !== pointer.id) {
      return;
    }
    event.preventDefault();
    if (holdTimer) {
      window.clearTimeout(holdTimer);
    }
    var elapsed = performance.now() - pointer.time;
    if (!pointer.swiped && !pointer.held && elapsed < 430) {
      attack(performance.now());
    }
    clearPointer(event);
  }

  function clearPointer(event) {
    if (holdTimer) {
      window.clearTimeout(holdTimer);
      holdTimer = null;
    }
    if (event && pointer && event.pointerId === pointer.id) {
      try {
        canvas.releasePointerCapture(event.pointerId);
      } catch (error) {
        // Ignore release errors.
      }
    }
    pointer = null;
  }

  function registerServiceWorker() {
    if ('serviceWorker' in navigator && window.location.protocol !== 'file:') {
      navigator.serviceWorker.register('service-worker.js').catch(function () {});
    }
  }

  resizeCanvas();
  initKeypad();
  renderTitleStats();
  bindEvents();
  updateUi();
  registerServiceWorker();
  window.requestAnimationFrame(loop);
}());
